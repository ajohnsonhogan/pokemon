from enum import Enum

class Type(Enum):
    BUG = 0
    DARK = 1
    DRAGON = 2
    ELECTRIC = 3
    FAIRY = 4
    FIRE = 5
    FIGHTING = 6
    FLYING = 7
    GROUND = 8
    GRASS = 9
    GHOST = 10
    ICE = 11
    NORMAL = 12
    POISON = 13
    WATER = 14
    PSYCHIC = 15
    ROCK = 16
    STEEL = 17